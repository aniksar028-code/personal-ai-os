# LYRA — Personal AI OS

A calm, local-first personal operating system for routines, health, goals, progress and AI guidance.

## Included now
- Premium dark-first responsive UI + light mode
- LYRA name + custom icon + PWA manifest
- Personal Blueprint: name, DOB, height, weight, schedule, preferences and focus areas
- Daily/weekly timeline with add/edit/delete/complete
- Health tracking: water, calories, protein, carbs, fat, sleep, steps, weight
- Health score and progress areas
- Goals with measurable progress
- Progress/consistency review
- LYRA AI local guidance + quick actions
- AI routine generator based on the blueprint
- Data export/import backup
- Offline service worker/PWA support
- GitHub Pages deployment workflow

## Important architecture note
The frontend intentionally does NOT contain a secret LLM API key. Real cloud AI should be connected through a secure backend endpoint. Supabase/PostgreSQL sync, reliable scheduled push notifications, device health APIs and native Android/Capacitor packaging are separate production integrations.

## Deploy
This repository is ready for GitHub Pages using GitHub Actions. Upload the project files to the repository root, ensure Pages source is **GitHub Actions**, then push to `main`.
