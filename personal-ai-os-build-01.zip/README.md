# Personal AI OS — Build 03
Home / Command Center with local routine tracking, Plan, Health, Progress and AI surfaces.
