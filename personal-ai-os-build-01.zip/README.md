# Personal AI OS — Build 05.1

Navigation fix for Build 05. Bottom navigation now switches between Home, Plan, Health, Progress and AI views instead of leaving the Health screen visible.
