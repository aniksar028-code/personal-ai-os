# Personal AI OS

A new-from-scratch personal AI operating system foundation.

## Development
- React + TypeScript
- Vite
- Mobile-first custom CSS
- PWA-ready manifest
