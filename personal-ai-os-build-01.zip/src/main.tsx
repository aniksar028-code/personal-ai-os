import React, {useEffect, useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

type Activity = {
  id:string; title:string; type:"Task"|"Habit"|"Meal"|"Workout"|"Study"|"Reminder";
  time:string; duration:string; done:boolean; day:number; note?:string;
};

const TYPES: Activity["type"][] = ["Task","Habit","Meal","Workout","Study","Reminder"];
const DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

function loadBlueprint(){
  try { return JSON.parse(localStorage.getItem("personal-ai-os-blueprint") || "{}"); }
  catch { return {}; }
}
function loadActivities():Activity[]{
  try {
    const x = JSON.parse(localStorage.getItem("personal-ai-os-activities") || "null");
    if(Array.isArray(x)) return x;
  } catch {}
  return [
    {id:"wake",title:"Wake up & reset",type:"Habit",time:"07:00",duration:"15 min",done:false,day:0},
    {id:"water",title:"Morning water",type:"Habit",time:"07:15",duration:"5 min",done:false,day:0},
    {id:"study",title:"Focused study",type:"Study",time:"09:00",duration:"90 min",done:false,day:0},
    {id:"lunch",title:"Lunch",type:"Meal",time:"13:00",duration:"30 min",done:false,day:0},
    {id:"walk",title:"Outdoor walk",type:"Workout",time:"17:30",duration:"30 min",done:false,day:0},
    {id:"review",title:"Daily review",type:"Task",time:"21:30",duration:"10 min",done:false,day:0}
  ];
}

function App(){
  const bp = useMemo(loadBlueprint,[]);
  const [tab,setTab] = useState<"home"|"plan"|"health"|"progress"|"ai">("plan");
  const [view,setView] = useState<"today"|"week">("today");
  const [selectedDay,setSelectedDay] = useState(0);
  const [items,setItems] = useState<Activity[]>(loadActivities);
  const [showAdd,setShowAdd] = useState(false);
  const [editing,setEditing] = useState<Activity|null>(null);
  const [toast,setToast] = useState("");

  useEffect(()=>localStorage.setItem("personal-ai-os-activities",JSON.stringify(items)),[items]);

  const dayItems = items.filter(x=>x.day===selectedDay).sort((a,b)=>a.time.localeCompare(b.time));
  const done = dayItems.filter(x=>x.done).length;
  const progress = dayItems.length ? Math.round(done/dayItems.length*100) : 0;

  function notify(msg:string){
    setToast(msg); window.setTimeout(()=>setToast(""),1800);
  }
  function toggle(id:string){
    setItems(a=>a.map(x=>x.id===id?{...x,done:!x.done}:x));
  }
  function remove(id:string){
    setItems(a=>a.filter(x=>x.id!==id)); notify("Activity removed");
  }
  function saveActivity(v:Activity){
    setItems(a=>a.some(x=>x.id===v.id)?a.map(x=>x.id===v.id?v:x):[...a,v]);
    setShowAdd(false); setEditing(null); notify("Plan updated");
  }
  function adapt(){
    const pending = items.filter(x=>x.day===selectedDay && !x.done).sort((a,b)=>a.time.localeCompare(b.time));
    if(!pending.length){notify("Your day is already clear");return}
    // Gentle adaptive action: move the next pending item 15 minutes later.
    const first=pending[0];
    const [h,m]=first.time.split(":").map(Number);
    const d=new Date(2000,0,1,h,m+15);
    const time=d.toTimeString().slice(0,5);
    setItems(a=>a.map(x=>x.id===first.id?{...x,time}:x));
    notify(`Adapted: ${first.title} → ${time}`);
  }

  const nav = (t:typeof tab)=>setTab(t);

  return <div className="os">
    <header className="topbar">
      <div>
        <div className="eyebrow">PERSONAL AI OS</div>
        <h1>Plan</h1>
      </div>
      <div className="avatar">{(bp.name||"A").slice(0,1).toUpperCase()}</div>
    </header>

    <main className="content">
      {tab==="plan" ? <>
        <section className="planHero card">
          <div>
            <span className="label">YOUR PLAN</span>
            <h2>{view==="today" ? "Make today intentional." : "Shape your week."}</h2>
            <p>AI can optimize the plan, but you stay in control.</p>
          </div>
          <button className="accentBtn" onClick={adapt}>Adapt My Day</button>
        </section>

        <div className="segmented">
          <button className={view==="today"?"active":""} onClick={()=>setView("today")}>Today</button>
          <button className={view==="week"?"active":""} onClick={()=>setView("week")}>Week</button>
        </div>

        {view==="today" ? <>
          <div className="dayStrip">
            {DAYS.map((d,i)=><button key={d} className={selectedDay===i?"day activeDay":"day"} onClick={()=>setSelectedDay(i)}>
              <span>{d}</span><b>{items.filter(x=>x.day===i && x.done).length}/{items.filter(x=>x.day===i).length}</b>
            </button>)}
          </div>

          <section className="progressCard card">
            <div><span>Today</span><strong>{progress}%</strong></div>
            <div className="progressTrack"><i style={{width:`${progress}%`}}/></div>
            <small>{done} of {dayItems.length} activities completed</small>
          </section>

          <div className="sectionHead"><div><span className="label">TIMELINE</span><h3>{DAYS[selectedDay]}</h3></div>
            <button className="addBtn" onClick={()=>setShowAdd(true)}>＋ Add</button>
          </div>

          <section className="timeline">
            {dayItems.length===0 && <div className="empty card">No activities yet.<br/><button onClick={()=>setShowAdd(true)}>Create your first activity</button></div>}
            {dayItems.map((x,idx)=><article className={`activity ${x.done?"completed":""}`} key={x.id}>
              <div className="time">{x.time}<small>{x.duration}</small></div>
              <div className="line"><span className="dot"/></div>
              <div className="activityBody card">
                <div className="activityTop">
                  <span className={`type type-${x.type.toLowerCase()}`}>{x.type}</span>
                  <button className="more" onClick={()=>setEditing(x)}>•••</button>
                </div>
                <h4>{x.title}</h4>
                {x.note && <p>{x.note}</p>}
                <div className="activityActions">
                  <button onClick={()=>toggle(x.id)}>{x.done?"Completed ✓":"Complete"}</button>
                  <button onClick={()=>setEditing(x)}>Edit</button>
                  <button onClick={()=>remove(x.id)}>Delete</button>
                </div>
              </div>
            </article>)}
          </section>
        </> : <WeekView items={items} onDay={setSelectedDay} onAdd={()=>setShowAdd(true)} />}
      </> : <Placeholder tab={tab} onPlan={()=>setTab("plan")} />}
    </main>

    <nav className="bottomNav">
      {(["home","plan","health","progress","ai"] as const).map(t=><button key={t} className={tab===t?"navActive":""} onClick={()=>nav(t)}>
        <span>{({home:"⌂",plan:"▤",health:"♡",progress:"◔",ai:"✦"} as any)[t]}</span><small>{t[0].toUpperCase()+t.slice(1)}</small>
      </button>)}
    </nav>

    {(showAdd||editing) && <ActivityModal initial={editing} day={selectedDay} onClose={()=>{setShowAdd(false);setEditing(null)}} onSave={saveActivity}/>}
    {toast && <div className="toast">{toast}</div>}
  </div>
}

function WeekView({items,onDay,onAdd}:{items:Activity[],onDay:(n:number)=>void,onAdd:()=>void}){
 return <section className="weekGrid">
   <div className="sectionHead"><div><span className="label">WEEK OVERVIEW</span><h3>Seven days, one direction.</h3></div><button className="addBtn" onClick={onAdd}>＋ Add</button></div>
   {DAYS.map((d,i)=>{
     const list=items.filter(x=>x.day===i).sort((a,b)=>a.time.localeCompare(b.time));
     const done=list.filter(x=>x.done).length;
     return <button className="weekDay card" key={d} onClick={()=>onDay(i)}>
       <div><b>{d}</b><span>{done}/{list.length} complete</span></div>
       <div className="miniTrack"><i style={{width:list.length?`${done/list.length*100}%`:"0%"}}/></div>
       <div className="weekItems">{list.slice(0,3).map(x=><span key={x.id} className={x.done?"strike":""}>{x.time} · {x.title}</span>)}{list.length>3&&<span>+{list.length-3} more</span>}</div>
     </button>
   })}
 </section>
}

function ActivityModal({initial,day,onClose,onSave}:{initial:Activity|null,day:number,onClose:()=>void,onSave:(v:Activity)=>void}){
 const [title,setTitle]=useState(initial?.title||"");
 const [type,setType]=useState<Activity["type"]>(initial?.type||"Task");
 const [time,setTime]=useState(initial?.time||"08:00");
 const [duration,setDuration]=useState(initial?.duration||"30 min");
 const [note,setNote]=useState(initial?.note||"");
 const [d,setD]=useState(initial?.day??day);
 function submit(e:React.FormEvent){e.preventDefault(); if(!title.trim())return;
   onSave({id:initial?.id||`a-${Date.now()}`,title:title.trim(),type,time,duration,done:initial?.done||false,day:d,note:note.trim()});
 }
 return <div className="modalBack">
   <form className="modal card" onSubmit={submit}>
     <div className="modalHead"><div><span className="label">{initial?"EDIT ACTIVITY":"NEW ACTIVITY"}</span><h2>{initial?"Refine your plan":"Add to your plan"}</h2></div><button type="button" onClick={onClose}>×</button></div>
     <label>Activity name<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Deep work session"/></label>
     <label>Type<select value={type} onChange={e=>setType(e.target.value as Activity["type"])}>{TYPES.map(t=><option key={t}>{t}</option>)}</select></label>
     <div className="two"><label>Time<input type="time" value={time} onChange={e=>setTime(e.target.value)}/></label><label>Duration<input value={duration} onChange={e=>setDuration(e.target.value)}/></label></div>
     <label>Day<select value={d} onChange={e=>setD(Number(e.target.value))}>{DAYS.map((x,i)=><option value={i} key={x}>{x}</option>)}</select></label>
     <label>Note <span className="optional">optional</span><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Anything useful to remember"/></label>
     <div className="modalActions"><button type="button" onClick={onClose}>Cancel</button><button className="accentBtn" type="submit">{initial?"Save changes":"Add activity"}</button></div>
   </form>
 </div>
}

function Placeholder({tab,onPlan}:{tab:string,onPlan:()=>void}){
 const data:any={home:["Home","Your command center is coming together.","Go to Plan to shape today's schedule."],health:["Health","Health intelligence will connect here.","Nutrition, hydration, movement and sleep will live here."],progress:["Progress","Your progress layer is next.","Consistency, trends and milestones will appear here."],ai:["AI","Your calm AI layer is next.","Ask, adapt and approve actions from one place."]};
 const [h,p,c]=data[tab];
 return <section className="placeholder card"><span className="label">{h.toUpperCase()}</span><h2>{p}</h2><p>{c}</p>{tab!=="plan"&&<button className="accentBtn" onClick={onPlan}>Open Plan</button>}</section>
}

createRoot(document.getElementById("root")!).render(<App/>);
