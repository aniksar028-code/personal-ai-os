import React, { useState } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'

type Tab = 'home' | 'plan' | 'health' | 'progress' | 'ai'

const tabs: {id: Tab; label: string; icon: string}[] = [
  {id:'home', label:'Home', icon:'⌂'},
  {id:'plan', label:'Plan', icon:'◷'},
  {id:'health', label:'Health', icon:'♡'},
  {id:'progress', label:'Progress', icon:'↗'},
  {id:'ai', label:'AI', icon:'✦'}
]

function App() {
  const [tab, setTab] = useState<Tab>('home')

  const render = () => {
    if (tab === 'home') return <Home setTab={setTab}/>
    if (tab === 'plan') return <Simple title="Plan" text="Your adaptive daily timeline will live here."/>
    if (tab === 'health') return <Simple title="Health" text="Nutrition, hydration, movement and sleep will live here."/>
    if (tab === 'progress') return <Simple title="Progress" text="Consistency, trends and goals will live here."/>
    return <Simple title="AI Assistant" text="Your personal AI command center will live here."/>
  }

  return (
    <div className="app-shell">
      <main className="page">{render()}</main>
      <nav className="bottom-nav">
        {tabs.map(t => (
          <button key={t.id} className={tab === t.id ? 'nav-item active' : 'nav-item'} onClick={() => setTab(t.id)}>
            <span className="nav-icon">{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}

function Home({setTab}: {setTab: (t: Tab)=>void}) {
  return (
    <>
      <header className="topbar">
        <div>
          <div className="eyebrow">PERSONAL AI OS</div>
          <h1>Good evening<span className="dot">.</span></h1>
        </div>
        <button className="profile-btn" aria-label="Profile">A</button>
      </header>

      <section className="hero-card">
        <div className="hero-label">TODAY</div>
        <div className="score-row">
          <strong>0%</strong>
          <span>Just getting started</span>
        </div>
        <div className="progress-track"><div className="progress-fill" style={{width:'0%'}}/></div>
      </section>

      <section className="section">
        <div className="section-head">
          <div>
            <div className="eyebrow">NOW</div>
            <h2>Start your day</h2>
          </div>
          <button className="text-btn" onClick={() => setTab('plan')}>View plan</button>
        </div>
        <div className="current-card">
          <div className="current-orb">✦</div>
          <div className="current-copy">
            <span className="muted">No activity scheduled</span>
            <strong>Your day will appear here</strong>
            <span className="muted small">Build your personal blueprint to begin.</span>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head"><div><div className="eyebrow">QUICK ACTIONS</div><h2>Make a move</h2></div></div>
        <div className="quick-grid">
          <button className="quick-card" onClick={() => setTab('plan')}><span>＋</span><b>Plan</b><small>Add an activity</small></button>
          <button className="quick-card" onClick={() => setTab('health')}><span>⌁</span><b>Log health</b><small>Food, water, sleep</small></button>
          <button className="quick-card" onClick={() => setTab('ai')}><span>✦</span><b>Ask AI</b><small>What should I do?</small></button>
        </div>
      </section>

      <section className="insight">
        <div className="insight-icon">✦</div>
        <div><div className="eyebrow">AI INSIGHT</div><p>Once your blueprint is ready, I’ll help turn your goals into a practical day.</p></div>
      </section>
    </>
  )
}

function Simple({title, text}: {title:string; text:string}) {
  return (
    <div className="simple-page">
      <div className="eyebrow">PERSONAL AI OS</div>
      <h1>{title}</h1>
      <p>{text}</p>
      <div className="placeholder-card"><span>✦</span><b>Foundation ready</b><small>This area will be built in the next development phase.</small></div>
    </div>
  )
}

createRoot(document.getElementById('root')!).render(
  <React.StrictMode><App /></React.StrictMode>
)
